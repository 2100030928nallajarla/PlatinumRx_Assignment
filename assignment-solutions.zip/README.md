# Assignment Solutions
This repository contains SQL, Python, and Spreadsheet solutions.
Structure:
- SQL/
- Python/
- Spreadsheet/
- Assignment_Solutions.pdf
