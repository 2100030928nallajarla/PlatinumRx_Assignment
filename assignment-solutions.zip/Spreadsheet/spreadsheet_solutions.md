# Spreadsheet Solutions
## 1. Populate ticket_created_at
=VLOOKUP(A2, tickets!$B:$D, 2, FALSE)

## 2a. Tickets created & closed same day
COUNTIFS(...)

## 2b. Same hour same day
COUNTIFS(...)
